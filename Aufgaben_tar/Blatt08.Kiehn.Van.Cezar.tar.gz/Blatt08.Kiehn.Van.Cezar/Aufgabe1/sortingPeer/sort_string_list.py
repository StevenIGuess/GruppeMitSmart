#!/usr/bin/env python3
#title	Sorting a list of strings and a list of integers

#lst{SortedListofStrings}
unsorted_word_list = ['ag','ga','a','aaa','ca']
sorted_word_list = sorted(unsorted_word_list)
print('unsorted_word_list={}'.format(unsorted_word_list))
print('  sorted_word_list={}'.format(sorted_word_list))
unsorted_int_list = [5,3,1,-4,0,6]
unsorted_int_list.sort()
print('unsorted_list2={}'.format(unsorted_int_list))
#lstend#
