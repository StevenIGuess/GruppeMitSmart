Die Werte zur Ableitung der Diagnosen stammen von
https://www.blutwert.net
