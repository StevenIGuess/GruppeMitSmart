Falls ein Unittest fehlschl"agt, k"onnen Sie das Programm
splitnumber_sol_mn.py nutzen, um Ihre Funktion f"ur eine zu zerlegende
Zahl und eine Liste von Zahlen m"oglicher Summenden aufzurufen.
Beispiel:

./splitnumber_sol_mn.py 38 7 11 13

liefert als Ausgabe:

(38,[7, 11, 13],[[7, 7, 11, 13]])
