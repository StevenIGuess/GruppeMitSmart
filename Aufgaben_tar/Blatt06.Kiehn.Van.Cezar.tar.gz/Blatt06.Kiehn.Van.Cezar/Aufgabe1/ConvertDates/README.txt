Der Text in chronik_der_BRD.txt wurde 
https://de.wikipedia.org/wiki/Geschichte_der_Bundesrepublik_Deutschland_(bis_1990)
entnommen und durch weiterer genaue Datumsangaben leicht modifiziert.

