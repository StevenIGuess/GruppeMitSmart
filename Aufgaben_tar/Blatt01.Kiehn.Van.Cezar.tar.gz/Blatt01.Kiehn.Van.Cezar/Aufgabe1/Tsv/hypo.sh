#!/bin/bash
cat islands.tsv | grep "hypothetical protein"