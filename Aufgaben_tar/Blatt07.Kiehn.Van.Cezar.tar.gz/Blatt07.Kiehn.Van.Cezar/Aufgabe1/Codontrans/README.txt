The file ZNF148_cds.txt contains the coding sequence of the
gene ZNF148 which codes the 'zinc finger protein 148' of Homo Sapiens.
More information is provided in the the Genbank-entry gbMultiseq/Library.gb
