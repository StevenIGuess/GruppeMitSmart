#!/usr/bin/env python3

import sys

# Hier den Programmcode einf"ugen
