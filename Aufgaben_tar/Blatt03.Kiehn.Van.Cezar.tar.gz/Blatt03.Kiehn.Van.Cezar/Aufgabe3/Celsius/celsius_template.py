#!/usr/bin/env python3

# in Terminal: mv celsius_template.py celsius.py

# Programmtext hier Einf"ugen
